# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

##---(Sat Feb 01 00:29:10 2014)---
runfile('C:/Users/AlexBEAST/Dropbox/Python/Games/GemTrap/Foosball/main.py', wdir=r'C:/Users/AlexBEAST/Dropbox/Python/Games/GemTrap/Foosball')

##---(Sat Feb 01 11:06:34 2014)---
i = 0
i += 1
i
runfile('C:/Users/AlexBEAST/Dropbox/Python/Games/GemTrap/Gemtrap/gemtrap.py', wdir=r'C:/Users/AlexBEAST/Dropbox/Python/Games/GemTrap/Gemtrap')