# -*- coding: utf-8 -*-
"""
Spyder Editor

This temporary script file is located here:
C:\Users\AlexBEAST\.spyder2\.temp.py
"""

