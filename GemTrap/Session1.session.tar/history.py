# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

##---(Sat Feb 01 00:29:10 2014)---
runfile('C:/Users/AlexBEAST/Dropbox/Python/Games/GemTrap/Foosball/main.py', wdir=r'C:/Users/AlexBEAST/Dropbox/Python/Games/GemTrap/Foosball')